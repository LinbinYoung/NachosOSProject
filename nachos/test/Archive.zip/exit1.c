/* 
 * exit1.c
 *
 * It does not get simpler than this...
 */
   
#include "syscall.h"

int
main (int argc, char *argv[])
{
    exit (123);
}
